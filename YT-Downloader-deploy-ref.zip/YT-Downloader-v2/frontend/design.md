## Web Design(Figma): [Click me](https://www.figma.com/file/ajel9s4bafgSUAycOFNyeh/Practical1?type=design&node-id=0%3A1&mode=dev&t=RtX93O1xlSpexoxv-1)
![Top (5)](https://github.com/Otuslettia/YT-Downloader/assets/95861205/14e965e3-3b00-45f0-8ef5-46e8538bdafd)
> Designed by: [Otuslettia](https://github.com/Otuslettia)
